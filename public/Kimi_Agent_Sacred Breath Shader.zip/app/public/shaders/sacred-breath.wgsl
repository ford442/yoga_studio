// ============================================================================
// SACRED BREATH SHADER — ENHANCED COLORFUL EDITION
// Immersive yoga breathing visualization with vibrant chakra colors,
// sacred geometry, particle effects, and aurora backgrounds
// ============================================================================

struct BreathUniforms {
  time: f32,
  phase: u32,           // 0=inhale, 1=hold1, 2=exhale, 3=hold2
  phaseProgress: f32,
  cycle: u32,
  strengthLevel: u32,
  intensity: f32,
};

@group(0) @binding(0) var<uniform> u_breath: BreathUniforms;
@group(0) @binding(1) var<uniform> iResolution: vec3<f32>;

// ============================================================================
// CONSTANTS — VIBRANT CHAKRA RAINBOW
// ============================================================================
const PI: f32 = 3.14159265359;
const TAU: f32 = 6.28318530718;
const PHI: f32 = 1.61803398875;

// Enhanced vibrant chakra colors
const CHAKRA_COLORS: array<vec3<f32>, 7> = array<vec3<f32>, 7>(
  vec3<f32>(1.0, 0.15, 0.05),      // Root - Deep Red
  vec3<f32>(1.0, 0.45, 0.0),       // Sacral - Vibrant Orange
  vec3<f32>(1.0, 0.85, 0.05),      // Solar Plexus - Golden Yellow
  vec3<f32>(0.15, 0.85, 0.25),     // Heart - Emerald Green
  vec3<f32>(0.05, 0.65, 1.0),      // Throat - Sky Blue
  vec3<f32>(0.35, 0.25, 0.95),     // Third Eye - Indigo
  vec3<f32>(0.75, 0.25, 0.95)      // Crown - Violet
);

// Phase colors with more vibrancy
const INHALE_COLOR: vec3<f32> = vec3<f32>(1.0, 0.7, 0.2);
const HOLD1_COLOR: vec3<f32> = vec3<f32>(1.0, 0.9, 0.5);
const EXHALE_COLOR: vec3<f32> = vec3<f32>(0.3, 0.6, 1.0);
const HOLD2_COLOR: vec3<f32> = vec3<f32>(0.5, 0.8, 0.6);

// Rainbow palette for aurora effects
const RAINBOW: array<vec3<f32>, 8> = array<vec3<f32>, 8>(
  vec3<f32>(1.0, 0.0, 0.0),    // Red
  vec3<f32>(1.0, 0.5, 0.0),    // Orange
  vec3<f32>(1.0, 1.0, 0.0),    // Yellow
  vec3<f32>(0.0, 1.0, 0.0),    // Green
  vec3<f32>(0.0, 1.0, 0.5),    // Spring
  vec3<f32>(0.0, 0.5, 1.0),    // Azure
  vec3<f32>(0.5, 0.0, 1.0),    // Violet
  vec3<f32>(1.0, 0.0, 0.5)     // Magenta
);

// ============================================================================
// MATH UTILITIES
// ============================================================================
fn hash2(p: vec2<f32>) -> vec2<f32> {
  let n = sin(p * mat2x2<f32>(127.1, 311.7, 269.5, 183.3));
  return fract(n * 43758.5453);
}

fn hash3(p: vec3<f32>) -> f32 {
  let n = sin(dot(p, vec3<f32>(127.1, 311.7, 74.7)));
  return fract(n * 43758.5453);
}

fn noise(p: vec2<f32>) -> f32 {
  let i = floor(p);
  let f = fract(p);
  f = f * f * (3.0 - 2.0 * f);
  let a = hash2(i).x;
  let b = hash2(i + vec2<f32>(1.0, 0.0)).x;
  let c = hash2(i + vec2<f32>(0.0, 1.0)).x;
  let d = hash2(i + vec2<f32>(1.0, 1.0)).x;
  return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

fn fbm(p: vec2<f32>) -> f32 {
  var v: f32 = 0.0;
  var a: f32 = 0.5;
  var pp = p;
  for(var i: i32 = 0; i < 5; i = i + 1) {
    v = v + a * noise(pp);
    pp = pp * 2.0;
    a = a * 0.5;
  }
  return v;
}

fn rot2(a: f32) -> mat2x2<f32> {
  let c = cos(a);
  let s = sin(a);
  return mat2x2<f32>(c, -s, s, c);
}

fn sdCircle(p: vec2<f32>, r: f32) -> f32 {
  return length(p) - r;
}

fn sdRing(p: vec2<f32>, r: f32, w: f32) -> f32 {
  let d = abs(length(p) - r);
  return smoothstep(w, 0.0, d);
}

// ============================================================================
// COLOR UTILITIES
// ============================================================================
fn hsb2rgb(c: vec3<f32>) -> vec3<f32> {
  let k = vec3<f32>(1.0, 2.0 / 3.0, 1.0 / 3.0);
  let p = abs(fract(c.xxx + k.xyz) * 6.0 - 3.0);
  return c.z * mix(vec3<f32>(1.0), clamp(p - 1.0, vec3<f32>(0.0), vec3<f32>(1.0)), c.y);
}

fn rgb2hsb(c: vec3<f32>) -> vec3<f32> {
  let k = vec4<f32>(0.0, -1.0 / 3.0, 2.0 / 3.0, -1.0);
  let p = mix(vec4<f32>(c.bg, k.wz), vec4<f32>(c.gb, k.xy), step(c.b, c.g));
  let q = mix(vec4<f32>(p.xyw, c.r), vec4<f32>(c.r, p.yzx), step(p.x, c.r));
  let d = q.x - min(q.w, q.y);
  let e = 1.0e-10;
  return vec3<f32>(abs(q.z + (q.w - q.y) / (6.0 * d + e)), d / (q.x + e), q.x);
}

// ============================================================================
// AURORA BACKGROUND — Ethereal flowing colors
// ============================================================================
fn aurora(uv: vec2<f32>, t: f32) -> vec3<f32> {
  var col = vec3<f32>(0.0);
  let intensity = u_breath.intensity;
  
  // Multiple aurora layers
  for(var i: i32 = 0; i < 5; i = i + 1) {
    let fi = f32(i);
    let offset = fi * 1.5;
    
    // Flowing aurora waves
    let wave1 = sin(uv.x * 2.0 + t * 0.5 + offset) * 0.5;
    let wave2 = sin(uv.x * 3.0 - t * 0.3 + offset * 1.3) * 0.3;
    let wave3 = sin(uv.x * 1.5 + t * 0.7 + offset * 0.7) * 0.4;
    
    let y = uv.y + wave1 + wave2 + wave3;
    
    // Aurora band
    let band = exp(-y * y * 8.0) * (0.5 + intensity * 0.5);
    
    // Color cycling based on position and time
    let hue = fract(fi * 0.15 + t * 0.05 + uv.x * 0.1);
    let sat = 0.7 + intensity * 0.2;
    let bri = band * (0.6 + intensity * 0.4);
    
    let auroraCol = hsb2rgb(vec3<f32>(hue, sat, bri));
    col = col + auroraCol * (0.15 + intensity * 0.1);
  }
  
  // Add nebula-like noise
  let nebula = fbm(uv * 3.0 + t * 0.1);
  let nebulaCol = hsb2rgb(vec3<f32>(fract(t * 0.02 + uv.x * 0.2), 0.6, nebula * 0.3));
  col = col + nebulaCol * intensity * 0.2;
  
  return col;
}

// ============================================================================
// SACRED GEOMETRY — Flower of Life, Sri Yantra elements
// ============================================================================
fn flowerOfLife(uv: vec2<f32>, t: f32) -> vec3<f32> {
  var col = vec3<f32>(0.0);
  let intensity = u_breath.intensity;
  let progress = u_breath.phaseProgress;
  
  // Central circle
  let centerGlow = exp(-length(uv) * 3.0) * (0.5 + intensity * 0.5);
  
  // Surrounding circles (Flower of Life pattern)
  let numCircles = 6;
  for(var i: i32 = 0; i < numCircles; i = i + 1) {
    let fi = f32(i);
    let angle = fi * TAU / f32(numCircles) + t * 0.1;
    let radius = 0.25 + progress * 0.1;
    let pos = vec2<f32>(cos(angle), sin(angle)) * radius;
    
    let d = length(uv - pos);
    let circle = exp(-d * d * 50.0) * (0.3 + intensity * 0.3);
    
    // Color based on chakra
    let chakraIdx = i % 7;
    let circleCol = CHAKRA_COLORS[chakraIdx] * circle;
    col = col + circleCol;
  }
  
  // Intersection points glow
  let intersections = exp(-length(uv) * 8.0) * centerGlow * 2.0;
  col = col + vec3<f32>(1.0, 0.9, 0.7) * intersections * intensity;
  
  return col;
}

fn sriYantra(uv: vec2<f32>, t: f32) -> vec3<f32> {
  var col = vec3<f32>(0.0);
  let intensity = u_breath.intensity;
  
  // Central bindu (point)
  let bindu = exp(-length(uv) * 100.0) * 2.0;
  col = col + vec3<f32>(1.0, 0.9, 0.5) * bindu;
  
  // Triangles radiating from center
  let numTriangles = 9;
  for(var i: i32 = 0; i < numTriangles; i = i + 1) {
    let fi = f32(i);
    let angle = fi * TAU / f32(numTriangles) + t * 0.05;
    let size = 0.1 + fi * 0.05;
    
    // Triangle vertices
    let v1 = vec2<f32>(cos(angle), sin(angle)) * size;
    let v2 = vec2<f32>(cos(angle + TAU / 3.0), sin(angle + TAU / 3.0)) * size;
    let v3 = vec2<f32>(cos(angle + 2.0 * TAU / 3.0), sin(angle + 2.0 * TAU / 3.0)) * size;
    
    // Distance to triangle edges
    let d1 = length(uv - v1);
    let d2 = length(uv - v2);
    let d3 = length(uv - v3);
    let minD = min(min(d1, d2), d3);
    
    let edgeGlow = exp(-minD * minD * 200.0) * 0.5 * intensity;
    let hue = fract(fi * 0.11 + t * 0.02);
    let triCol = hsb2rgb(vec3<f32>(hue, 0.8, edgeGlow));
    col = col + triCol;
  }
  
  return col;
}

// ============================================================================
// CHAKRA VISUALIZATION — Enhanced with particle effects
// ============================================================================
fn chakras(uv: vec2<f32>, t: f32) -> vec3<f32> {
  var col = vec3<f32>(0.0);
  let phase = u_breath.phase;
  let progress = u_breath.phaseProgress;
  let intensity = u_breath.intensity;
  
  // Wave offset based on breath phase
  var waveOffset: f32 = 0.0;
  switch(phase) {
    case 0u: { waveOffset = progress * 7.0; }
    case 1u: { waveOffset = 7.0; }
    case 2u: { waveOffset = 7.0 - progress * 7.0; }
    case 3u: { waveOffset = 0.0; }
    default: {}
  }
  
  // Phase tint
  var phaseTint = vec3<f32>(0.0);
  switch(phase) {
    case 0u: { phaseTint = INHALE_COLOR * progress * 0.4; }
    case 1u: { phaseTint = HOLD1_COLOR * 0.3; }
    case 2u: { phaseTint = EXHALE_COLOR * progress * 0.4; }
    case 3u: { phaseTint = HOLD2_COLOR * 0.2; }
    default: {}
  }
  
  // Seven chakras along the spine
  for(var i: i32 = 0; i < 7; i = i + 1) {
    let fi = f32(i);
    let y = -0.5 + fi * 0.17;
    let cp = uv - vec2<f32>(0.0, y);
    let dist = length(cp);
    
    // Wave propagation
    let wavePos = fi - waveOffset;
    let waveGlow = exp(-wavePos * wavePos * 1.5) * intensity;
    
    // Chakra color with phase influence
    var ccol = CHAKRA_COLORS[i];
    ccol = mix(ccol, phaseTint + vec3<f32>(0.5), 0.25);
    
    // Active chakra highlight based on phase
    var active: f32 = 0.0;
    if phase == 0u && (i == 3 || i == 4) { active = 1.0; }
    if phase == 1u && i == 2 { active = 1.0; }
    if phase == 2u && i == 0 { active = 1.0; }
    if phase == 3u && i == 6 { active = 1.0; }
    
    // Pulsing size
    let pulse = 0.7 + 0.3 * sin(t * 3.0 + fi * 0.8);
    let size = 0.025 + 0.012 * waveGlow + 0.008 * active;
    
    // Glow with bloom effect
    let glow = exp(-dist / size) * (0.6 + waveGlow * 0.6 + active * 0.4) * pulse;
    
    // Add bloom ring
    let ring = sdRing(cp, size * 2.0, 0.01) * 0.3 * intensity;
    
    col = col + ccol * glow * intensity;
    col = col + ccol * ring * 0.5;
    
    // Energy flow between chakras during inhale
    if phase == 0u && uv.y > y && uv.y < y + 0.2 {
      let flow = exp(-abs(uv.x) * 25.0) * progress * (1.0 - (uv.y - y) / 0.2);
      col = col + ccol * flow * 0.4 * intensity;
    }
  }
  
  // Central channel (sushumna) glow
  let channelGlow = exp(-abs(uv.x) * 20.0) * 0.15 * intensity;
  col = col + vec3<f32>(1.0, 0.95, 0.8) * channelGlow;
  
  return col;
}

// ============================================================================
// PARTICLE FIELD — Sparkling energy particles
// ============================================================================
fn particles(uv: vec2<f32>, t: f32) -> vec3<f32> {
  var col = vec3<f32>(0.0);
  let intensity = u_breath.intensity;
  let progress = u_breath.phaseProgress;
  let phase = u_breath.phase;
  
  let numParticles = 30;
  for(var i: i32 = 0; i < numParticles; i = i + 1) {
    let fi = f32(i);
    let hash = hash2(vec2<f32>(fi, fi * 1.5));
    
    // Particle orbit
    let orbitRadius = 0.2 + hash.x * 0.5;
    let orbitSpeed = 0.3 + hash.y * 0.4;
    let angle = t * orbitSpeed + fi * 0.5;
    
    let px = cos(angle) * orbitRadius;
    let py = sin(angle * 0.7 + hash.y * TAU) * orbitRadius * 0.6;
    let ppos = vec2<f32>(px, py);
    
    // Distance to particle
    let d = length(uv - ppos);
    
    // Particle size varies with breath
    let psize = 0.008 + 0.006 * intensity * (1.0 + sin(t * 4.0 + fi) * 0.3);
    if phase == 0u {
      let psize = psize * (1.0 + progress * 0.5);
    }
    
    let particle = exp(-d / psize) * (0.5 + intensity * 0.5);
    
    // Rainbow color cycling
    let hue = fract(fi * 0.03 + t * 0.05 + progress * 0.1);
    let pcol = hsb2rgb(vec3<f32>(hue, 0.9, particle));
    
    col = col + pcol * 0.3;
  }
  
  return col;
}

// ============================================================================
// BREATH ORBS — Pulsing energy spheres
// ============================================================================
fn breathOrbs(uv: vec2<f32>, t: f32) -> vec3<f32> {
  var col = vec3<f32>(0.0);
  let phase = u_breath.phase;
  let progress = u_breath.phaseProgress;
  let intensity = u_breath.intensity;
  
  // Central breath orb
  var orbRadius: f32 = 0.15;
  switch(phase) {
    case 0u: { orbRadius = 0.15 + progress * 0.25; }  // Expand on inhale
    case 1u: { orbRadius = 0.4; }                      // Hold full
    case 2u: { orbRadius = 0.4 - progress * 0.25; }   // Contract on exhale
    case 3u: { orbRadius = 0.15; }                     // Hold empty
    default: {}
  }
  
  let d = length(uv);
  let orbDist = abs(d - orbRadius);
  
  // Phase color
  var orbCol = vec3<f32>(1.0);
  switch(phase) {
    case 0u: { orbCol = mix(vec3<f32>(0.5), INHALE_COLOR, progress); }
    case 1u: { orbCol = HOLD1_COLOR; }
    case 2u: { orbCol = mix(HOLD1_COLOR, EXHALE_COLOR, progress); }
    case 3u: { orbCol = HOLD2_COLOR; }
    default: {}
  }
  
  // Outer glow ring
  let ringGlow = exp(-orbDist * orbDist * 80.0) * (0.8 + intensity * 0.4);
  col = col + orbCol * ringGlow;
  
  // Inner fill with gradient
  let innerGlow = exp(-d * d * 30.0) * 0.3 * intensity;
  col = col + orbCol * innerGlow;
  
  // Concentric rings (energy waves)
  for(var i: i32 = 1; i < 4; i = i + 1) {
    let fi = f32(i);
    let ringR = orbRadius + fi * 0.08;
    let ringWave = sin(d * 20.0 - t * 3.0 - fi) * 0.5 + 0.5;
    let ring = sdRing(uv, ringR, 0.003) * ringWave * 0.3 * intensity;
    col = col + orbCol * ring;
  }
  
  return col;
}

// ============================================================================
// MANDALA PATTERN — Rotating sacred patterns
// ============================================================================
fn mandala(uv: vec2<f32>, t: f32) -> vec3<f32> {
  var col = vec3<f32>(0.0);
  let intensity = u_breath.intensity;
  let progress = u_breath.phaseProgress;
  
  // Convert to polar
  let r = length(uv);
  let a = atan2(uv.y, uv.x);
  
  // Rotating mandala layers
  let numPetals = 12;
  for(var i: i32 = 0; i < 3; i = i + 1) {
    let fi = f32(i);
    let rotation = t * (0.1 + fi * 0.05) * (1.0 + progress * 0.5);
    let petals = sin(a * f32(numPetals) + rotation + fi) * 0.5 + 0.5;
    
    let ringR = 0.5 + fi * 0.15;
    let ring = sdRing(uv, ringR, 0.02) * petals;
    
    let hue = fract(fi * 0.15 + t * 0.03);
    let petalCol = hsb2rgb(vec3<f32>(hue, 0.8, ring * intensity * 0.5));
    col = col + petalCol;
  }
  
  // Central star
  let star = sin(a * 8.0) * 0.5 + 0.5;
  let starGlow = exp(-r * 5.0) * star * 0.3 * intensity;
  col = col + vec3<f32>(1.0, 0.9, 0.5) * starGlow;
  
  return col;
}

// ============================================================================
// MAIN RENDER
// ============================================================================
@vertex
fn vs_main(@builtin(vertex_index) vid: u32) -> @builtin(position) vec4<f32> {
  let pos = array<vec2<f32>, 6>(
    vec2<f32>(-1.0, -1.0), vec2<f32>(1.0, -1.0), vec2<f32>(-1.0, 1.0),
    vec2<f32>(1.0, -1.0), vec2<f32>(1.0, 1.0), vec2<f32>(-1.0, 1.0)
  );
  return vec4<f32>(pos[vid], 0.0, 1.0);
}

@fragment
fn fs_main(@builtin(position) fragCoord: vec4<f32>) -> @location(0) vec4<f32> {
  // Normalized coordinates
  let uv = (fragCoord.xy - 0.5 * iResolution.xy) / min(iResolution.x, iResolution.y);
  let t = u_breath.time;
  let intensity = u_breath.intensity;
  let phase = u_breath.phase;
  let progress = u_breath.phaseProgress;
  
  // Start with dark cosmic background
  var col = vec3<f32>(0.01, 0.005, 0.02);
  
  // Layer 1: Aurora background
  let auroraUV = uv * 2.0;
  let auroraCol = aurora(auroraUV, t);
  col = col + auroraCol * 0.4;
  
  // Layer 2: Mandala (background layer)
  let mandalaCol = mandala(uv * 1.5, t);
  col = col + mandalaCol * 0.3 * intensity;
  
  // Layer 3: Flower of Life
  let folCol = flowerOfLife(uv * 0.8, t);
  col = col + folCol * 0.25 * intensity;
  
  // Layer 4: Sri Yantra elements
  let sriCol = sriYantra(uv * 1.2, t);
  col = col + sriCol * 0.2 * intensity;
  
  // Layer 5: Chakras
  let chakraCol = chakras(uv, t);
  col = col + chakraCol;
  
  // Layer 6: Breath orbs (central focus)
  let orbCol = breathOrbs(uv, t);
  col = col + orbCol;
  
  // Layer 7: Particles (foreground sparkles)
  let particleCol = particles(uv, t);
  col = col + particleCol;
  
  // Vignette for focus
  let vignette = 1.0 - length(uv * 0.7) * length(uv * 0.7) * 0.4;
  col = col * vignette;
  
  // Phase-based color grading
  var tint = vec3<f32>(1.0);
  switch(phase) {
    case 0u: { tint = mix(vec3<f32>(1.0), INHALE_COLOR, progress * 0.15); }
    case 1u: { tint = mix(INHALE_COLOR, vec3<f32>(1.0), 0.1); }
    case 2u: { tint = mix(vec3<f32>(1.0), EXHALE_COLOR, progress * 0.15); }
    case 3u: { tint = mix(EXHALE_COLOR, vec3<f32>(1.0), 0.1); }
    default: {}
  }
  col = col * tint;
  
  // Subtle glow boost during intense moments
  let glowBoost = 1.0 + intensity * 0.2 * sin(t * 2.0);
  col = col * glowBoost;
  
  // Tone mapping for vibrant colors
  col = col / (1.0 + col * 0.3);
  
  // Gamma correction
  col = pow(col, vec3<f32>(0.9));
  
  return vec4<f32>(col, 1.0);
}
