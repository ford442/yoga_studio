import type { BreathPhase } from '@/hooks/useSacredBreath';

interface BreathGuidanceProps {
  phase: BreathPhase;
  phaseProgress: number;
  countdown: number;
}

const phaseInstructions: Record<BreathPhase, { title: string; instruction: string; tip: string }> = {
  inhale: {
    title: 'Inhale',
    instruction: 'Breathe in through your nose, filling your lungs completely',
    tip: 'Let your belly expand first, then your chest',
  },
  hold1: {
    title: 'Hold',
    instruction: 'Hold your breath gently, staying relaxed',
    tip: 'Keep your body soft, no tension needed',
  },
  exhale: {
    title: 'Exhale',
    instruction: 'Breathe out slowly through your nose or mouth',
    tip: 'Release all tension with your breath',
  },
  hold2: {
    title: 'Hold',
    instruction: 'Pause with empty lungs, staying calm',
    tip: 'Embrace the stillness between breaths',
  },
};

export function BreathGuidance({ phase, phaseProgress, countdown }: BreathGuidanceProps) {
  const guidance = phaseInstructions[phase];
  
  return (
    <div className="flex flex-col items-center text-center space-y-4 animate-fade-in">
      {/* Phase Title */}
      <div className="relative">
        <h2 className="text-5xl md:text-7xl font-light tracking-wider uppercase text-white/90">
          {guidance.title}
        </h2>
        {/* Animated underline */}
        <div 
          className="absolute -bottom-2 left-0 h-0.5 bg-gradient-to-r from-transparent via-white/60 to-transparent transition-all duration-300"
          style={{ width: `${phaseProgress * 100}%` }}
        />
      </div>
      
      {/* Countdown */}
      <div className="text-8xl md:text-9xl font-thin tabular-nums text-white/95">
        {countdown}
      </div>
      
      {/* Instruction */}
      <p className="text-lg md:text-xl text-white/70 max-w-md leading-relaxed">
        {guidance.instruction}
      </p>
      
      {/* Tip */}
      <div className="flex items-center gap-2 text-white/50 text-sm">
        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
        <span>{guidance.tip}</span>
      </div>
    </div>
  );
}

export default BreathGuidance;
