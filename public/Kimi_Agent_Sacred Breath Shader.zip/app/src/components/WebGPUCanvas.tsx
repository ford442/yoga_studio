import { forwardRef, useImperativeHandle, useRef, useEffect, useCallback, useState } from 'react';

export interface WebGPUCanvasRef {
  updateUniforms: (data: {
    time: number;
    phase: number;
    phaseProgress: number;
    cycle: number;
    strengthLevel: number;
    intensity: number;
  }) => void;
}

interface WebGPUCanvasProps {
  shaderPath?: string;
}

const WebGPUCanvas = forwardRef<WebGPUCanvasRef, WebGPUCanvasProps>(
  ({ shaderPath = '/shaders/sacred-breath.wgsl' }, ref) => {
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const uniformBufferRef = useRef<GPUBuffer | null>(null);
    const deviceRef = useRef<GPUDevice | null>(null);
    const pipelineRef = useRef<GPURenderPipeline | null>(null);
    const contextRef = useRef<GPUCanvasContext | null>(null);
    const animationRef = useRef<number | null>(null);
    const bindGroupRef = useRef<GPUBindGroup | null>(null);
    const resolutionBufferRef = useRef<GPUBuffer | null>(null);
    const [error, setError] = useState<string | null>(null);
    const [isInitialized, setIsInitialized] = useState(false);

    // Fallback shader in case file loading fails
    const fallbackShader = `
      struct BreathUniforms {
        time: f32,
        phase: u32,
        phaseProgress: f32,
        cycle: u32,
        strengthLevel: u32,
        intensity: f32,
      };
      @group(0) @binding(0) var<uniform> u_breath: BreathUniforms;
      @group(0) @binding(1) var<uniform> iResolution: vec3<f32>;
      
      const PI: f32 = 3.14159265359;
      const TAU: f32 = 6.28318530718;
      
      fn hsb2rgb(c: vec3<f32>) -> vec3<f32> {
        let k = vec3<f32>(1.0, 2.0 / 3.0, 1.0 / 3.0);
        let p = abs(fract(c.xxx + k.xyz) * 6.0 - 3.0);
        return c.z * mix(vec3<f32>(1.0), clamp(p - 1.0, vec3<f32>(0.0), vec3<f32>(1.0)), c.y);
      }
      
      @vertex
      fn vs_main(@builtin(vertex_index) vid: u32) -> @builtin(position) vec4<f32> {
        let pos = array<vec2<f32>, 6>(
          vec2<f32>(-1.0, -1.0), vec2<f32>(1.0, -1.0), vec2<f32>(-1.0, 1.0),
          vec2<f32>(1.0, -1.0), vec2<f32>(1.0, 1.0), vec2<f32>(-1.0, 1.0)
        );
        return vec4<f32>(pos[vid], 0.0, 1.0);
      }
      
      @fragment
      fn fs_main(@builtin(position) fragCoord: vec4<f32>) -> @location(0) vec4<f32> {
        let uv = (fragCoord.xy - 0.5 * iResolution.xy) / min(iResolution.x, iResolution.y);
        let t = u_breath.time;
        let phase = u_breath.phase;
        let progress = u_breath.phaseProgress;
        let intensity = u_breath.intensity;
        
        // Dark cosmic background
        var col = vec3<f32>(0.01, 0.005, 0.02);
        
        // Animated aurora
        for(var i: i32 = 0; i < 4; i = i + 1) {
          let fi = f32(i);
          let wave = sin(uv.x * 2.0 + t * 0.5 + fi * 1.5) * 0.3;
          let y = uv.y + wave;
          let band = exp(-y * y * 6.0) * 0.3;
          let hue = fract(fi * 0.2 + t * 0.03);
          col = col + hsb2rgb(vec3<f32>(hue, 0.8, band)) * intensity;
        }
        
        // Central breath orb
        var orbRadius: f32 = 0.2;
        switch(phase) {
          case 0u: { orbRadius = 0.2 + progress * 0.25; }
          case 1u: { orbRadius = 0.45; }
          case 2u: { orbRadius = 0.45 - progress * 0.25; }
          case 3u: { orbRadius = 0.2; }
          default: {}
        }
        
        let d = length(uv);
        let orbDist = abs(d - orbRadius);
        
        // Phase colors
        var orbCol = vec3<f32>(1.0);
        switch(phase) {
          case 0u: { orbCol = vec3<f32>(1.0, 0.7, 0.2); }
          case 1u: { orbCol = vec3<f32>(1.0, 0.9, 0.5); }
          case 2u: { orbCol = vec3<f32>(0.3, 0.6, 1.0); }
          case 3u: { orbCol = vec3<f32>(0.5, 0.8, 0.6); }
          default: {}
        }
        
        let ringGlow = exp(-orbDist * orbDist * 60.0) * (0.8 + intensity * 0.4);
        col = col + orbCol * ringGlow;
        
        // Inner glow
        let innerGlow = exp(-d * d * 25.0) * 0.3 * intensity;
        col = col + orbCol * innerGlow;
        
        // Rotating particles
        for(var i: i32 = 0; i < 12; i = i + 1) {
          let fi = f32(i);
          let angle = t * 0.5 + fi * TAU / 12.0;
          let radius = 0.4 + fi * 0.03;
          let px = cos(angle) * radius;
          let py = sin(angle) * radius;
          let pd = length(uv - vec2<f32>(px, py));
          let particle = exp(-pd * pd * 500.0) * 0.5 * intensity;
          let hue = fract(fi * 0.08 + t * 0.02);
          col = col + hsb2rgb(vec3<f32>(hue, 0.9, particle));
        }
        
        // Vignette
        let vignette = 1.0 - length(uv * 0.7) * length(uv * 0.7) * 0.4;
        col = col * vignette;
        
        // Tone mapping
        col = col / (1.0 + col * 0.3);
        col = pow(col, vec3<f32>(0.9));
        
        return vec4<f32>(col, 1.0);
      }
    `;

    // Load shader from file
    const loadShader = async (): Promise<string> => {
      try {
        const response = await fetch(shaderPath);
        if (!response.ok) throw new Error('Failed to load shader');
        return await response.text();
      } catch (e) {
        console.warn('Could not load shader file, using fallback');
        return fallbackShader;
      }
    };

    // Initialize WebGPU
    const initWebGPU = useCallback(async () => {
      if (!canvasRef.current) return;

      if (!navigator.gpu) {
        setError('WebGPU not supported. Please use Chrome 113+ or Edge 113+');
        return;
      }

      try {
        const adapter = await navigator.gpu.requestAdapter({
          powerPreference: 'high-performance',
        });

        if (!adapter) {
          setError('No WebGPU adapter found');
          return;
        }

        const device = await adapter.requestDevice();
        deviceRef.current = device;

        const context = canvasRef.current.getContext('webgpu');
        if (!context) {
          setError('Failed to get WebGPU context');
          return;
        }
        contextRef.current = context;

        const format = navigator.gpu.getPreferredCanvasFormat();
        context.configure({
          device,
          format,
          alphaMode: 'premultiplied',
        });

        // Load and compile shader
        const shaderCode = await loadShader();
        const shaderModule = device.createShaderModule({
          code: shaderCode,
          label: 'sacred-breath',
        });

        // Check for compilation errors
        const compilationInfo = await shaderModule.getCompilationInfo();
        if (compilationInfo.messages.length > 0) {
          for (const msg of compilationInfo.messages) {
            if (msg.type === 'error') {
              console.error('Shader compilation error:', msg.message, 'at line', msg.lineNum);
            }
          }
        }

        // Create pipeline
        const pipeline = device.createRenderPipeline({
          layout: 'auto',
          vertex: {
            module: shaderModule,
            entryPoint: 'vs_main',
          },
          fragment: {
            module: shaderModule,
            entryPoint: 'fs_main',
            targets: [{ format }],
          },
          primitive: {
            topology: 'triangle-list',
          },
        });
        pipelineRef.current = pipeline;

        // Create uniform buffer (6 floats = 24 bytes)
        const uniformBuffer = device.createBuffer({
          size: 6 * 4,
          usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST,
        });
        uniformBufferRef.current = uniformBuffer;

        // Create resolution buffer (vec3<f32> padded to 16 bytes)
        const resolutionBuffer = device.createBuffer({
          size: 16,
          usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST,
        });
        resolutionBufferRef.current = resolutionBuffer;

        // Create bind group
        const bindGroup = device.createBindGroup({
          layout: pipeline.getBindGroupLayout(0),
          entries: [
            { binding: 0, resource: { buffer: uniformBuffer } },
            { binding: 1, resource: { buffer: resolutionBuffer } },
          ],
        });
        bindGroupRef.current = bindGroup;

        // Set initial resolution
        const rect = canvasRef.current.getBoundingClientRect();
        canvasRef.current.width = Math.max(1, Math.floor(rect.width));
        canvasRef.current.height = Math.max(1, Math.floor(rect.height));
        device.queue.writeBuffer(
          resolutionBuffer,
          0,
          new Float32Array([rect.width, rect.height, 1.0, 0.0])
        );

        setIsInitialized(true);
      } catch (e) {
        console.error('WebGPU initialization failed:', e);
        setError('WebGPU initialization failed: ' + (e as Error).message);
      }
    }, [shaderPath]);

    // Update uniforms
    const updateUniforms = useCallback(
      (data: {
        time: number;
        phase: number;
        phaseProgress: number;
        cycle: number;
        strengthLevel: number;
        intensity: number;
      }) => {
        if (!uniformBufferRef.current || !deviceRef.current) return;

        const array = new Float32Array([
          data.time,
          data.phase,
          data.phaseProgress,
          data.cycle,
          data.strengthLevel,
          data.intensity,
        ]);
        deviceRef.current.queue.writeBuffer(uniformBufferRef.current, 0, array);
      },
      []
    );

    useImperativeHandle(
      ref,
      () => ({ updateUniforms }),
      [updateUniforms]
    );

    // Render loop
    const render = useCallback(() => {
      const device = deviceRef.current;
      const context = contextRef.current;
      const pipeline = pipelineRef.current;
      const bindGroup = bindGroupRef.current;

      if (!device || !context || !pipeline || !bindGroup) {
        animationRef.current = requestAnimationFrame(render);
        return;
      }

      try {
        const encoder = device.createCommandEncoder();
        const textureView = context.getCurrentTexture().createView();
        const pass = encoder.beginRenderPass({
          colorAttachments: [
            {
              view: textureView,
              loadOp: 'clear',
              clearValue: [0.0, 0.0, 0.02, 1.0],
              storeOp: 'store',
            },
          ],
        });
        pass.setPipeline(pipeline);
        pass.setBindGroup(0, bindGroup);
        pass.draw(6);
        pass.end();
        device.queue.submit([encoder.finish()]);
      } catch (e) {
        console.error('Render error:', e);
      }

      animationRef.current = requestAnimationFrame(render);
    }, []);

    // Initialize on mount
    useEffect(() => {
      initWebGPU();
      return () => {
        if (animationRef.current) {
          cancelAnimationFrame(animationRef.current);
        }
        uniformBufferRef.current?.destroy();
        resolutionBufferRef.current?.destroy();
        deviceRef.current?.destroy();
      };
    }, [initWebGPU]);

    // Start render loop when initialized
    useEffect(() => {
      if (isInitialized && pipelineRef.current) {
        animationRef.current = requestAnimationFrame(render);
        return () => {
          if (animationRef.current) {
            cancelAnimationFrame(animationRef.current);
          }
        };
      }
    }, [isInitialized, render]);

    // Handle resize
    useEffect(() => {
      const handleResize = () => {
        if (
          canvasRef.current &&
          resolutionBufferRef.current &&
          deviceRef.current
        ) {
          const rect = canvasRef.current.getBoundingClientRect();
          canvasRef.current.width = Math.max(1, Math.floor(rect.width));
          canvasRef.current.height = Math.max(1, Math.floor(rect.height));
          deviceRef.current.queue.writeBuffer(
            resolutionBufferRef.current,
            0,
            new Float32Array([rect.width, rect.height, 1.0, 0.0])
          );
        }
      };

      handleResize();
      window.addEventListener('resize', handleResize);
      return () => window.removeEventListener('resize', handleResize);
    }, []);

    if (error) {
      return (
        <div className="flex items-center justify-center w-full h-full bg-slate-900 text-red-400 p-8 text-center">
          <div>
            <p className="text-lg font-semibold mb-2">WebGPU Error</p>
            <p className="text-sm opacity-80">{error}</p>
            <p className="text-xs mt-4 text-slate-400">
              Please use Chrome 113+, Edge 113+, or another browser with WebGPU support
            </p>
          </div>
        </div>
      );
    }

    return (
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full"
        style={{ imageRendering: 'crisp-edges' }}
      />
    );
  }
);

WebGPUCanvas.displayName = 'WebGPUCanvas';

export default WebGPUCanvas;
