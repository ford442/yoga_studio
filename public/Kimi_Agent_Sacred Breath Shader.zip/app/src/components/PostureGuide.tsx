import type { BreathPhase } from '@/hooks/useSacredBreath';

interface PostureGuideProps {
  phase: BreathPhase;
}

const postureData: Record<BreathPhase, { name: string; description: string; alignment: string[] }> = {
  inhale: {
    name: 'Opening Posture',
    description: 'Expand and receive',
    alignment: [
      'Spine lengthens upward',
      'Shoulders roll back and down',
      'Chest gently opens',
      'Crown of head lifts',
    ],
  },
  hold1: {
    name: 'Full Retention',
    description: 'Contain the energy',
    alignment: [
      'Maintain lifted posture',
      'Jaw relaxed, face soft',
      'Energy rises through spine',
      'Stay present and aware',
    ],
  },
  exhale: {
    name: 'Releasing Posture',
    description: 'Let go and soften',
    alignment: [
      'Shoulders melt downward',
      'Body releases tension',
      'Root grounding down',
      'Mind stays clear',
    ],
  },
  hold2: {
    name: 'Empty Stillness',
    description: 'Rest in the pause',
    alignment: [
      'Complete relaxation',
      'No holding or forcing',
      'Natural suspension',
      'Deep inner calm',
    ],
  },
};

export function PostureGuide({ phase }: PostureGuideProps) {
  const posture = postureData[phase];
  
  return (
    <div className="bg-black/30 backdrop-blur-md rounded-2xl p-6 border border-white/10">
      <div className="flex items-center gap-3 mb-4">
        <div className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center">
          <svg className="w-5 h-5 text-white/70" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
          </svg>
        </div>
        <div>
          <h3 className="text-white/90 font-medium">{posture.name}</h3>
          <p className="text-white/50 text-sm">{posture.description}</p>
        </div>
      </div>
      
      <ul className="space-y-2">
        {posture.alignment.map((item, index) => (
          <li key={index} className="flex items-start gap-2 text-white/60 text-sm">
            <span className="w-1.5 h-1.5 rounded-full bg-white/40 mt-1.5 flex-shrink-0" />
            <span>{item}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default PostureGuide;
