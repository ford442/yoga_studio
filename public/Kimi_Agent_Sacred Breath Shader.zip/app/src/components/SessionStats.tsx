interface SessionStatsProps {
  cycle: number;
  totalTime: number;
  isRunning: boolean;
}

function formatTime(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
}

export function SessionStats({ cycle, totalTime, isRunning }: SessionStatsProps) {
  return (
    <div className="flex items-center gap-8">
      {/* Cycle Counter */}
      <div className="text-center">
        <div className="text-3xl font-light text-white/90 tabular-nums">
          {cycle}
        </div>
        <div className="text-xs text-white/50 uppercase tracking-wider">Cycles</div>
      </div>

      {/* Divider */}
      <div className="w-px h-10 bg-white/20" />

      {/* Timer */}
      <div className="text-center">
        <div className={`text-3xl font-light tabular-nums ${isRunning ? 'text-white/90' : 'text-white/50'}`}>
          {formatTime(totalTime)}
        </div>
        <div className="text-xs text-white/50 uppercase tracking-wider">Session Time</div>
      </div>

      {/* Divider */}
      <div className="w-px h-10 bg-white/20" />

      {/* Status Indicator */}
      <div className="text-center">
        <div className={`w-3 h-3 rounded-full mx-auto mb-1 ${isRunning ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`} />
        <div className="text-xs text-white/50 uppercase tracking-wider">
          {isRunning ? 'Active' : 'Paused'}
        </div>
      </div>
    </div>
  );
}

export default SessionStats;
