import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { STRENGTH_MULTIPLIERS } from '@/hooks/useSacredBreath';

interface BreathControlsProps {
  isRunning: boolean;
  strengthLevel: number;
  pattern: string;
  onStart: () => void;
  onPause: () => void;
  onReset: () => void;
  onStrengthChange: (level: number) => void;
  onPatternChange: (pattern: string) => void;
}

export function BreathControls({
  isRunning,
  strengthLevel,
  pattern,
  onStart,
  onPause,
  onReset,
  onStrengthChange,
  onPatternChange,
}: BreathControlsProps) {
  return (
    <div className="flex flex-wrap items-center justify-center gap-4">
      {/* Start/Pause Button */}
      <Button
        onClick={isRunning ? onPause : onStart}
        size="lg"
        className={`
          px-8 py-6 text-lg font-medium rounded-full transition-all duration-300
          ${isRunning 
            ? 'bg-amber-500/80 hover:bg-amber-400 text-white' 
            : 'bg-gradient-to-r from-indigo-500 to-purple-500 hover:from-indigo-400 hover:to-purple-400 text-white shadow-lg shadow-indigo-500/25'
          }
        `}
      >
        {isRunning ? (
          <>
            <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 9v6m4-6v6m7-3a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            Pause
          </>
        ) : (
          <>
            <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            Begin Sacred Breath
          </>
        )}
      </Button>

      {/* Pattern Selector */}
      <Select value={pattern} onValueChange={onPatternChange}>
        <SelectTrigger className="w-48 bg-black/40 border-white/20 text-white backdrop-blur-sm">
          <SelectValue placeholder="Select pattern" />
        </SelectTrigger>
        <SelectContent className="bg-slate-900/95 border-white/20">
          <SelectItem value="balanced">Balanced (4-4-6-2)</SelectItem>
          <SelectItem value="relaxing">Relaxing (4-7-8)</SelectItem>
          <SelectItem value="box">Box (5-5-5-5)</SelectItem>
          <SelectItem value="coherent">Coherent (6-6)</SelectItem>
          <SelectItem value="simple">Simple (4-6)</SelectItem>
        </SelectContent>
      </Select>

      {/* Strength Selector */}
      <Select value={strengthLevel.toString()} onValueChange={(v) => onStrengthChange(Number(v))}>
        <SelectTrigger className="w-40 bg-black/40 border-white/20 text-white backdrop-blur-sm">
          <SelectValue placeholder="Intensity" />
        </SelectTrigger>
        <SelectContent className="bg-slate-900/95 border-white/20">
          {STRENGTH_MULTIPLIERS.map((level, index) => (
            <SelectItem key={index} value={index.toString()}>
              {level.label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

      {/* Reset Button */}
      <Button
        onClick={onReset}
        variant="outline"
        size="lg"
        className="px-6 py-6 rounded-full border-white/20 text-white/70 hover:bg-white/10 hover:text-white backdrop-blur-sm"
      >
        <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
        </svg>
        Reset
      </Button>
    </div>
  );
}

export default BreathControls;
