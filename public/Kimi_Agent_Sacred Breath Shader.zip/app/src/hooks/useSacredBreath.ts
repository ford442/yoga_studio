import { useState, useEffect, useCallback, useRef } from 'react';

export type BreathPhase = 'inhale' | 'hold1' | 'exhale' | 'hold2';

export interface BreathConfig {
  inhale: number;
  hold1: number;
  exhale: number;
  hold2: number;
}

// Different breathing patterns
export const BREATH_PATTERNS: Record<string, BreathConfig> = {
  // 4-4-6-2 - Balanced calming breath
  balanced: { inhale: 4, hold1: 4, exhale: 6, hold2: 2 },
  // 4-7-8 - Relaxing breath (Dr. Weil)
  relaxing: { inhale: 4, hold1: 7, exhale: 8, hold2: 0 },
  // 5-5-5-5 - Box breathing
  box: { inhale: 5, hold1: 5, exhale: 5, hold2: 5 },
  // 6-0-6-0 - Coherent breathing
  coherent: { inhale: 6, hold1: 0, exhale: 6, hold2: 0 },
  // 4-0-6-0 - Simple calming
  simple: { inhale: 4, hold1: 0, exhale: 6, hold2: 0 },
};

// Strength level multipliers
const STRENGTH_MULTIPLIERS = [
  { label: 'Gentle', multiplier: 0.75, description: 'Softer breath for beginners' },
  { label: 'Balanced', multiplier: 1.0, description: 'Standard breathing rhythm' },
  { label: 'Deep', multiplier: 1.25, description: 'Deeper breath for advanced practice' },
  { label: 'Power', multiplier: 1.5, description: 'Intense breath for energy building' },
];

export interface SacredBreathState {
  phase: BreathPhase;
  phaseProgress: number;
  cycle: number;
  countdown: number;
  totalTime: number;
  isRunning: boolean;
  strengthLevel: number;
  pattern: string;
  intensity: number;
}

export interface SacredBreathActions {
  start: () => void;
  pause: () => void;
  reset: () => void;
  setStrengthLevel: (level: number) => void;
  setPattern: (pattern: string) => void;
  getUniforms: () => {
    time: number;
    phase: number;
    phaseProgress: number;
    cycle: number;
    strengthLevel: number;
    intensity: number;
  };
}

export function useSacredBreath(
  initialStrength: number = 1,
  initialPattern: string = 'balanced'
): SacredBreathState & SacredBreathActions {
  const [phase, setPhase] = useState<BreathPhase>('inhale');
  const [phaseProgress, setPhaseProgress] = useState(0);
  const [cycle, setCycle] = useState(0);
  const [countdown, setCountdown] = useState(BREATH_PATTERNS[initialPattern].inhale);
  const [totalTime, setTotalTime] = useState(0);
  const [isRunning, setIsRunning] = useState(false);
  const [strengthLevel, setStrengthLevel] = useState(initialStrength);
  const [pattern, setPatternState] = useState(initialPattern);
  const [intensity, setIntensity] = useState(0.5);

  const startTimeRef = useRef(performance.now());
  const phaseStartRef = useRef(performance.now());
  const rafRef = useRef<number | null>(null);
  const totalTimeRef = useRef(0);

  const phases: BreathPhase[] = ['inhale', 'hold1', 'exhale', 'hold2'];

  const getCurrentConfig = useCallback((): BreathConfig => {
    return BREATH_PATTERNS[pattern] || BREATH_PATTERNS.balanced;
  }, [pattern]);

  const getPhaseDuration = useCallback((p: BreathPhase): number => {
    const config = getCurrentConfig();
    const baseDuration = config[p];
    const multiplier = STRENGTH_MULTIPLIERS[strengthLevel]?.multiplier || 1.0;
    return Math.max(1, baseDuration * multiplier);
  }, [getCurrentConfig, strengthLevel]);

  const tick = useCallback(() => {
    if (!isRunning) return;

    const now = performance.now();
    const dur = getPhaseDuration(phase);
    const elapsed = (now - phaseStartRef.current) / 1000;
    const progress = Math.min(elapsed / dur, 1);

    setPhaseProgress(progress);
    setCountdown(Math.max(0, Math.ceil(dur - elapsed)));
    setTotalTime(totalTimeRef.current + (now - startTimeRef.current) / 1000);

    // Calculate intensity based on phase and progress
    let newIntensity = 0.5;
    switch (phase) {
      case 'inhale':
        newIntensity = 0.3 + progress * 0.5; // Ramp up
        break;
      case 'hold1':
        newIntensity = 0.8 + Math.sin(elapsed * 3) * 0.1; // Pulse at peak
        break;
      case 'exhale':
        newIntensity = 0.8 - progress * 0.5; // Ramp down
        break;
      case 'hold2':
        newIntensity = 0.3 + Math.sin(elapsed * 2) * 0.1; // Gentle pulse at rest
        break;
    }
    setIntensity(newIntensity);

    if (elapsed >= dur) {
      const nextIdx = (phases.indexOf(phase) + 1) % 4;
      const nextPhase = phases[nextIdx];
      
      // Skip hold phases if duration is 0
      if (getPhaseDuration(nextPhase) <= 0) {
        const skipIdx = (nextIdx + 1) % 4;
        const skipPhase = phases[skipIdx];
        setPhase(skipPhase);
        phaseStartRef.current = now;
        if (skipIdx === 0) {
          setCycle(c => c + 1);
        }
        setCountdown(getPhaseDuration(skipPhase));
      } else {
        setPhase(nextPhase);
        phaseStartRef.current = now;
        if (nextIdx === 0) {
          setCycle(c => c + 1);
        }
        setCountdown(getPhaseDuration(nextPhase));
      }
      setPhaseProgress(0);
    }

    rafRef.current = requestAnimationFrame(tick);
  }, [isRunning, phase, getPhaseDuration, phases]);

  useEffect(() => {
    if (isRunning) {
      phaseStartRef.current = performance.now();
      rafRef.current = requestAnimationFrame(tick);
    }
    return () => {
      if (rafRef.current) {
        cancelAnimationFrame(rafRef.current);
      }
    };
  }, [isRunning, tick]);

  const start = useCallback(() => {
    if (!isRunning) {
      startTimeRef.current = performance.now();
      phaseStartRef.current = performance.now();
      setIsRunning(true);
    }
  }, [isRunning]);

  const pause = useCallback(() => {
    if (isRunning) {
      totalTimeRef.current = totalTime;
      setIsRunning(false);
    }
  }, [isRunning, totalTime]);

  const reset = useCallback(() => {
    setIsRunning(false);
    setPhase('inhale');
    setPhaseProgress(0);
    setCycle(0);
    setCountdown(getPhaseDuration('inhale'));
    setTotalTime(0);
    totalTimeRef.current = 0;
    setIntensity(0.5);
  }, [getPhaseDuration]);

  const setPattern = useCallback((newPattern: string) => {
    setPatternState(newPattern);
    if (!isRunning) {
      const config = BREATH_PATTERNS[newPattern];
      setCountdown(config.inhale);
    }
  }, [isRunning]);

  const getUniforms = useCallback(() => ({
    time: performance.now() / 1000,
    phase: phases.indexOf(phase),
    phaseProgress,
    cycle,
    strengthLevel,
    intensity,
  }), [phase, phaseProgress, cycle, strengthLevel, intensity, phases]);

  return {
    phase,
    phaseProgress,
    cycle,
    countdown,
    totalTime,
    isRunning,
    strengthLevel,
    pattern,
    intensity,
    start,
    pause,
    reset,
    setStrengthLevel,
    setPattern,
    getUniforms,
  };
}

export { STRENGTH_MULTIPLIERS };
