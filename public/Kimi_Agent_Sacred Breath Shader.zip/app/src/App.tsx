import { useRef, useEffect, useState } from 'react';
import WebGPUCanvas, { type WebGPUCanvasRef } from './components/WebGPUCanvas';
import { useSacredBreath } from './hooks/useSacredBreath';
import { BreathGuidance } from './components/BreathGuidance';
import { PostureGuide } from './components/PostureGuide';
import { SessionStats } from './components/SessionStats';
import { Button } from './components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from './components/ui/dialog';

function App() {
  const breath = useSacredBreath(1, 'balanced');
  const shaderRef = useRef<WebGPUCanvasRef>(null);
  const [showInfo, setShowInfo] = useState(false);

  // Update shader uniforms on each frame
  useEffect(() => {
    if (!shaderRef.current) return;

    const update = () => {
      shaderRef.current?.updateUniforms(breath.getUniforms());
      requestAnimationFrame(update);
    };
    const raf = requestAnimationFrame(update);
    return () => cancelAnimationFrame(raf);
  }, [breath.phase, breath.phaseProgress, breath.cycle, breath.strengthLevel, breath.intensity]);

  const patternLabel = {
    balanced: '4-4-6-2 (Balanced)',
    relaxing: '4-7-8 (Relaxing)',
    box: '5-5-5-5 (Box)',
    coherent: '6-6 (Coherent)',
    simple: '4-6 (Simple)',
  }[breath.pattern];

  return (
    <main className="relative w-screen h-screen bg-black overflow-hidden">
      {/* WebGPU Shader Background */}
      <WebGPUCanvas 
        ref={shaderRef} 
        shaderPath="/shaders/sacred-breath.wgsl"
      />

      {/* Main Content Overlay */}
      <div className="absolute inset-0 flex flex-col pointer-events-none">
        {/* Header */}
        <header className="flex items-center justify-between p-6 pointer-events-auto">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center">
              <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" />
              </svg>
            </div>
            <div>
              <h1 className="text-white/90 font-medium text-lg">Sacred Breath</h1>
              <p className="text-white/50 text-xs">Yoga Pranayama Practice</p>
            </div>
          </div>

          <Dialog open={showInfo} onOpenChange={setShowInfo}>
            <DialogTrigger asChild>
              <Button variant="ghost" size="icon" className="text-white/60 hover:text-white hover:bg-white/10">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-slate-900/95 border-white/10 text-white max-w-lg">
              <DialogHeader>
                <DialogTitle className="text-xl">About Sacred Breath</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 text-white/70">
                <p>
                  Sacred Breath is a guided pranayama (yogic breathing) practice that helps you 
                  cultivate mindfulness, reduce stress, and balance your energy.
                </p>
                <div>
                  <h4 className="text-white font-medium mb-2">Breathing Patterns</h4>
                  <ul className="space-y-2 text-sm">
                    <li><span className="text-indigo-400">Balanced (4-4-6-2):</span> General wellbeing and focus</li>
                    <li><span className="text-indigo-400">Relaxing (4-7-8):</span> Deep relaxation and sleep preparation</li>
                    <li><span className="text-indigo-400">Box (5-5-5-5):</span> Stress relief and concentration</li>
                    <li><span className="text-indigo-400">Coherent (6-6):</span> Heart rate variability and calm</li>
                    <li><span className="text-indigo-400">Simple (4-6):</span> Beginner-friendly calming breath</li>
                  </ul>
                </div>
                <div>
                  <h4 className="text-white font-medium mb-2">How to Practice</h4>
                  <ol className="space-y-1 text-sm list-decimal list-inside">
                    <li>Find a comfortable seated position</li>
                    <li>Select a breathing pattern that suits your needs</li>
                    <li>Follow the visual guidance and breathe naturally</li>
                    <li>Let the colors and patterns guide your rhythm</li>
                  </ol>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </header>

        {/* Center Content - Breath Guidance */}
        <div className="flex-1 flex items-center justify-center">
          <div className="pointer-events-auto">
            <BreathGuidance 
              phase={breath.phase} 
              phaseProgress={breath.phaseProgress}
              countdown={breath.countdown}
            />
          </div>
        </div>

        {/* Bottom Controls */}
        <div className="p-6 space-y-6">
          {/* Stats */}
          <div className="flex justify-center pointer-events-auto">
            <SessionStats 
              cycle={breath.cycle} 
              totalTime={breath.totalTime}
              isRunning={breath.isRunning}
            />
          </div>

          {/* Controls */}
          <div className="flex flex-wrap items-center justify-center gap-3 pointer-events-auto">
            {/* Start/Pause Button */}
            <Button
              onClick={breath.isRunning ? breath.pause : breath.start}
              size="lg"
              className={`
                px-8 py-6 text-lg font-medium rounded-full transition-all duration-300
                ${breath.isRunning 
                  ? 'bg-amber-500/80 hover:bg-amber-400 text-white' 
                  : 'bg-gradient-to-r from-indigo-500 to-purple-500 hover:from-indigo-400 hover:to-purple-400 text-white shadow-lg shadow-indigo-500/25'
                }
              `}
            >
              {breath.isRunning ? (
                <>
                  <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 9v6m4-6v6m7-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  Pause
                </>
              ) : (
                <>
                  <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  Begin Sacred Breath
                </>
              )}
            </Button>

            {/* Pattern Selector */}
            <Select value={breath.pattern} onValueChange={breath.setPattern}>
              <SelectTrigger className="w-48 bg-black/40 border-white/20 text-white backdrop-blur-sm hover:bg-black/60 transition-colors">
                <SelectValue placeholder="Select pattern" />
              </SelectTrigger>
              <SelectContent className="bg-slate-900/95 border-white/20">
                <SelectItem value="balanced">Balanced (4-4-6-2)</SelectItem>
                <SelectItem value="relaxing">Relaxing (4-7-8)</SelectItem>
                <SelectItem value="box">Box (5-5-5-5)</SelectItem>
                <SelectItem value="coherent">Coherent (6-6)</SelectItem>
                <SelectItem value="simple">Simple (4-6)</SelectItem>
              </SelectContent>
            </Select>

            {/* Intensity Selector */}
            <Select 
              value={breath.strengthLevel.toString()} 
              onValueChange={(v) => breath.setStrengthLevel(Number(v))}
            >
              <SelectTrigger className="w-36 bg-black/40 border-white/20 text-white backdrop-blur-sm hover:bg-black/60 transition-colors">
                <SelectValue placeholder="Intensity" />
              </SelectTrigger>
              <SelectContent className="bg-slate-900/95 border-white/20">
                <SelectItem value="0">Gentle</SelectItem>
                <SelectItem value="1">Balanced</SelectItem>
                <SelectItem value="2">Deep</SelectItem>
                <SelectItem value="3">Power</SelectItem>
              </SelectContent>
            </Select>

            {/* Reset Button */}
            <Button
              onClick={breath.reset}
              variant="outline"
              size="lg"
              className="px-6 py-6 rounded-full border-white/20 text-white/70 hover:bg-white/10 hover:text-white backdrop-blur-sm"
            >
              <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
              </svg>
              Reset
            </Button>
          </div>

          {/* Current Pattern Display */}
          <div className="text-center">
            <span className="text-white/40 text-sm">
              Current Pattern: <span className="text-white/60">{patternLabel}</span>
            </span>
          </div>
        </div>
      </div>

      {/* Progress Ring (SVG) */}
      <svg 
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[400px] h-[400px] md:w-[500px] md:h-[500px] pointer-events-none opacity-30"
        viewBox="0 0 200 200"
      >
        <circle 
          cx="100" 
          cy="100" 
          r="90" 
          fill="none" 
          stroke="rgba(165, 180, 252, 0.3)" 
          strokeWidth="2"
        />
        <circle 
          cx="100" 
          cy="100" 
          r="90" 
          fill="none" 
          stroke="rgba(165, 180, 252, 0.6)" 
          strokeWidth="3"
          strokeLinecap="round"
          strokeDasharray="565"
          strokeDashoffset={565 * (1 - breath.phaseProgress)}
          style={{ 
            transformOrigin: 'center',
            transform: 'rotate(-90deg)',
            transition: 'stroke-dashoffset 0.1s linear'
          }}
        />
      </svg>

      {/* Side Panel - Posture Guide (visible on larger screens) */}
      <div className="hidden lg:block absolute right-8 top-1/2 -translate-y-1/2 w-64 pointer-events-auto">
        <PostureGuide phase={breath.phase} />
      </div>
    </main>
  );
}

export default App;
